package groovy.swt.examples.guibuilder;

import groovy.jface.JFaceBuilder;
import groovy.lang.Binding;
import groovy.util.GroovyScriptEngine;

/**
 * @author <a href="mailto:ckl@dacelo.nl">Christiaan ten Klooster </a>
 * @version $Revision: 1027 $
 */
public class RunGuiBuilderDemo {

    public static void main(String[] args) throws Exception {
        String basePath = "src/main/groovy/groovy/swt/guibuilder";
        GroovyScriptEngine scriptEngine = new GroovyScriptEngine(basePath);

        Binding binding = new Binding();
        JFaceBuilder guiBuilder = new JFaceBuilder();
        binding.setVariable("guiBuilder", guiBuilder);

        scriptEngine.run("GuiBuilderDemo.groovy", binding);
    }

}